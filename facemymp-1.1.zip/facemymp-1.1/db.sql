-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 07, 2010 at 09:03 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6-1+lenny8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `facemymp`
--

-- --------------------------------------------------------

--
-- Table structure for table `aus_rep`
--

CREATE TABLE IF NOT EXISTS `aus_rep` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `party` varchar(255) NOT NULL,
  `constituency` varchar(255) NOT NULL,
  `active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `aus_rep_photo`
--

CREATE TABLE IF NOT EXISTS `aus_rep_photo` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `aus_rep_id` int(10) unsigned NOT NULL,
  `guid` varchar(32) NOT NULL,
  `attrib` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `aus_sen`
--

CREATE TABLE IF NOT EXISTS `aus_sen` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `party` varchar(255) NOT NULL,
  `active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `aus_sen_photo`
--

CREATE TABLE IF NOT EXISTS `aus_sen_photo` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `aus_sen_id` int(10) unsigned NOT NULL,
  `guid` varchar(32) NOT NULL,
  `attrib` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `lord`
--

CREATE TABLE IF NOT EXISTS `lord` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `party` varchar(255) NOT NULL,
  `active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lord_photo`
--

CREATE TABLE IF NOT EXISTS `lord_photo` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `lord_id` int(10) unsigned NOT NULL,
  `guid` varchar(32) NOT NULL,
  `attrib` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mla`
--

CREATE TABLE IF NOT EXISTS `mla` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `party` varchar(255) NOT NULL,
  `constituency` varchar(255) NOT NULL,
  `active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mla_photo`
--

CREATE TABLE IF NOT EXISTS `mla_photo` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `mla_id` int(10) unsigned NOT NULL,
  `guid` varchar(32) NOT NULL,
  `attrib` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mp`
--

CREATE TABLE IF NOT EXISTS `mp` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `party` varchar(255) NOT NULL,
  `constituency` varchar(255) NOT NULL,
  `active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `mp_photo`
--

CREATE TABLE IF NOT EXISTS `mp_photo` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `mp_id` int(10) unsigned NOT NULL,
  `guid` varchar(32) NOT NULL,
  `attrib` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `msp`
--

CREATE TABLE IF NOT EXISTS `msp` (
  `id` int(10) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `party` varchar(255) NOT NULL,
  `constituency` varchar(255) NOT NULL,
  `active` tinyint(1) unsigned NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `msp_photo`
--

CREATE TABLE IF NOT EXISTS `msp_photo` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `msp_id` int(10) unsigned NOT NULL,
  `guid` varchar(32) NOT NULL,
  `attrib` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `report_photo`
--

CREATE TABLE IF NOT EXISTS `report_photo` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `person_id` int(10) unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  `guid` varchar(32) NOT NULL,
  `comments` longtext,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `unapproved_photo`
--

CREATE TABLE IF NOT EXISTS `unapproved_photo` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `person_id` int(10) unsigned NOT NULL,
  `type` varchar(10) NOT NULL,
  `guid` varchar(32) NOT NULL,
  `attrib` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `updates`
--

CREATE TABLE IF NOT EXISTS `updates` (
  `id` varchar(10) NOT NULL,
  `lastupdated` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `updates`
--

INSERT INTO `updates` (`id`, `lastupdated`) VALUES
('mp', '2010-01-01 00:00:00'),
('lord', '2010-01-01 00:00:00'),
('msp', '2010-01-01 00:00:00'),
('mla', '2010-01-01 00:00:00'),
('aus_rep', '2010-01-01 00:00:00'),
('aus_sen', '2010-01-01 00:00:00');

/*
    This file is part of FaceMyMP.

    FaceMyMP is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    FaceMyMP is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FaceMyMP.  If not, see <http://www.gnu.org/licenses/>.

*/

function approvePhoto(id, name, realname, attrib) {
	window.location = '/account/admin/approvephoto?id=' + id + '&name=' + name + '&attrib=' + encodeURIComponent(attrib);
}

function approvePhotoQuick(id, name, realname) {
	if (confirm('Are you sure you want to approve this photo of ' + realname + '?')) {
		window.location = '/account/admin/approvephoto?id=' + id + '&name=' + name + '&cropped=0';
	}
}

function rejectPhoto(id, name, hash, realname) {
	if (confirm('Are you sure you want to reject this photo of ' + realname + '?')) {
		window.location = '/account/admin/rejectphoto?id=' + id + '&name=' + name + '&hash=' + hash;
	}
}

function deleteReport(id, resource) {
	if (confirm('Are you sure you want to delete this report?')) {
		window.location = '/account/admin/deletereport?id=' + id + '&resource=' + resource;
	}
}

function selectAll(selectall, name) {
	var control = document.getElementById(selectall);
	var refs = document.getElementsByName(name);
	for (var i = 0; i < refs.length; i++) {
		refs[i].checked = control.checked;
	}
}
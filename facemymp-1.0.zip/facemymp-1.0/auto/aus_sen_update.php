<?php

/*
    This file is part of FaceMyMP.

    FaceMyMP is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    FaceMyMP is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FaceMyMP.  If not, see <http://www.gnu.org/licenses/>.

*/

// * START EDITING HERE *
$api_key = ''; // Your API key for OpenAustralia.org

// Database credentials
$db_server = 'localhost'; // Almost always localhost
$db_username = ''; // Database username
$db_password = ''; // Database password
$db_database = ''; // Database name

// * STOP EDITING HERE *

// Update list of Senators from OpenAustralia.org API

// Get the data
$rawdata = unserialize(file_get_contents('http://www.openaustralia.org/api/getSenators?key='.$api_key.'&output=php'));

// Do some sanity checks
if (!is_array($rawdata))
{
	echo '<p>An error occurred when attempting to retrieve data from OpenAustralia.org.</p>';
}
else
{
	// Connect to MySQL
	mysql_connect($db_server, $db_username, $db_password);
	mysql_select_db($db_database);

	// Make sure we're talking in Unicode
	mysql_query('SET NAMES "utf8"');
	mysql_query('SET CHARACTER SET "utf8"');

	// Mark all Senators as being inactive
	mysql_query('UPDATE aus_sen SET `active` = 0');

	// Check each Senator to see if they are in the database. If so, mark them as active. If not, add them.
	echo '<ul>';
	for ($i = 0; $i < count($rawdata); $i++)
	{
		// Find out if we already have the Senator in the database
		if (mysql_num_rows(mysql_query('SELECT id FROM aus_sen WHERE `id` = '.$rawdata[$i]['person_id'])) > 0)
		{
			// The Senator is already there, so update their details
			mysql_query('UPDATE aus_sen SET `name` = "'.utf8_encode($rawdata[$i]['name']).'", `party` = "'.utf8_encode($rawdata[$i]['party']).'", `active` = 1 WHERE `id` = '.$rawdata[$i]['person_id']);
			echo '<li><strong>UPDATE:</strong> '.utf8_encode($rawdata[$i]['name']).' marked as active.</li>';
		}
		else
		{
			// We have a new Senator on our hands, so insert a new record
			mysql_query('INSERT INTO aus_sen (`id`,`name`,`party`,`active`) VALUES ('.$rawdata[$i]['person_id'].',"'.utf8_encode($rawdata[$i]['name']).'","'.utf8_encode($rawdata[$i]['party']).'",1)');
			echo '<li><strong>ADD:</strong> '.utf8_encode($rawdata[$i]['name']).' added to database.</li>';
		}
	}
	echo '</ul>';

	// Update timestamp
	mysql_query('UPDATE updates SET `lastupdated` = "'.date('Y-m-d H:i:s').'" WHERE `id` = "aus_sen"');

	// Disconnect from MySQL
	mysql_close();
}

?>

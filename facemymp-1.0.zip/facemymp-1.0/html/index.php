<?php

/*
    This file is part of FaceMyMP.

    FaceMyMP is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    FaceMyMP is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with FaceMyMP.  If not, see <http://www.gnu.org/licenses/>.

*/

// * START EDITING HERE *

// Enable or disable logging in
$_LOGIN = true;

// Enable or disable uploading photos
$_UPLOADS = true;

// Database credentials
$db_server = 'localhost'; // Almost always localhost
$db_username = ''; // Database username
$db_password = ''; // Database password
$db_database = ''; // Database name
$db_database_users = ''; // Database name for users

// API keys - insert your API keys for the sites below
$twfy_apikey = ''; // TheyWorkForYou.com
$oa_apikey = ''; // OpenAustralia.org
$rpx_apikey = ''; // RPXnow.com
$rpx_url = ''; // Custom RPX URL with trailing slash (e.g. https://example.rpxnow.com/)

// MD5 hash secret for file deletions - insert some random characters and symbols here; the more random, the better!
$secret = '';

// Photo details
$uploaddir = ''; // Full path to the folder where photos will be uploaded
$uploadurl = ''; // The URL corresponding to the path above (no trailing slash)

// The URL of this website
$websiteurl = ''; // No trailing slash

// The email address that contact form submissions should be sent to
$contact_recipient = '';

// * STOP EDITING HERE *

// Connect to MySQL and select database
mysql_connect($db_server, $db_username, $db_password) OR die('Could not connect to database server.');
mysql_select_db($db_database) OR die('Could not select database.');

// Make sure that we're talking in Unicode
mysql_query('SET NAMES "utf8"');
mysql_query('SET CHARACTER SET "utf8"');

// OpenID support via RPX
require_once 'RPX.php';
$rpx = new RPX($rpx_apikey, $rpx_url);

// Start off our session
session_start();

// Account levels
$_accountlevel = array(0 => 'User', 1 => 'Uploader', 2 => 'Moderator', 3 => 'Administrator', 9 => 'Super Administrator');

// Start output buffering
ob_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>FaceMyMP</title>
<link rel="stylesheet" type="text/css" media="screen" href="/styles.css">
<link rel="stylesheet" type="text/css" media="print" href="/styles-print.css">
<link rel="stylesheet" type="text/css" media="handheld" href="/styles-handheld.css">
<link rel="stylesheet" type="text/css" media="only screen and (max-device-width: 480px)" href="/styles-iphone.css">
<link rel="stylesheet" type="text/css" media="screen" href="/scripts/lightbox.css">
<link rel="stylesheet" type="text/css" media="screen" href="/scripts/admin/cropper/cropper.css">
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/prototype/1.6.1.0/prototype.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/scriptaculous/1.8.3/scriptaculous.js"></script>
<script type="text/javascript" src="/scripts/lightbox.js"></script>
<script type="text/javascript" src="/scripts/photos.js"></script>
</head>

<body>
<div id="wrapper"><a id="top"></a>

<div id="skiplinks"><a href="#content" title="Skip to main content [Accesskey: 2]" accesskey="2" tabindex="2">Skip to main content (<strong class="accesskey">2</strong>)</a></div>

<div id="header"><h1><span id="header-face">Face</span><span id="header-my">My</span><span id="header-mp">MP</span></h1><h2>Find out or tell us what a politician looks like</h2></div>

<?php if ($_LOGIN) { ?>
<?php if (isset($_SESSION['loggedin'])) { ?>
<div id="login">Hello <a href="/account" title="Account [Accesskey: u]" accesskey="u"><?php echo $_SESSION['name']; ?></a>. <a href="/logout?r=<?php echo $_SERVER['REQUEST_URI']; ?>" title="Log out [Accesskey: g]" accesskey="g">Lo<strong class="accesskey">g</strong> out</a></div>
<?php } else { ?>
<form action="' . $rpx_url . 'openid/start?token_url=' . $websiteurl . '/login?r=<?php echo $_SERVER['REQUEST_URI']; ?>" method="post" id="login"><div><input type="text" name="openid_identifier" id="openidlogin" size="30"></div></form>
<?php } ?>
<?php } ?>

<div id="nav"><ul><li id="navhome"><a href="/" title="Home [Accesskey: h]" accesskey="h" tabindex="1"><strong class="accesskey">H</strong>ome</a></li><li id="navabout"><a href="/about" title="About [Accesskey: b]" accesskey="b">A<strong class="accesskey">b</strong>out</a></li><li id="navcontact"><a href="/contact" title="Contact [Accesskey: c]" accesskey="c"><strong class="accesskey">C</strong>ontact</a></li></ul><div style="clear: both;"></div></div>

<div id="subnav"><ul><li><strong><abbr title="United Kingdom">UK</abbr>:</strong></li><li id="navmp"><a href="/mp" title="MPs (Members of Parliament) [Accesskey: m]" accesskey="m"><strong class="accesskey">M</strong>Ps</a></li><li id="navlord"><a href="/lord" title="Lords [Accesskey: l]" accesskey="l"><strong class="accesskey">L</strong>ords</a></li><li id="navmsp"><a href="/msp" title="MSPs (Members of the Scottish Parliament) [Accesskey: s]" accesskey="s">M<strong class="accesskey">S</strong>Ps</a></li><li id="navmla"><a href="/mla" title="MLAs (Members of the Legislative Assembly of Northern Ireland) [Accesskey: a]" accesskey="a">ML<strong class="accesskey">A</strong>s</a></li><li><strong>Australia:</strong></li><li id="navaus_rep"><a href="/aus_rep" title="Representatives [Accesskey: r]" accesskey="r"><strong class="accesskey">R</strong>epresentatives</a></li><li id="navaus_sen"><a href="/aus_sen" title="Senators [Accesskey: n]" accesskey="n">Se<strong class="accesskey">n</strong>ators</a></li></ul><div style="clear: both;"></div></div>

<div id="content">

<?php

// Expand the query string
$qs = explode('&', $_SERVER['QUERY_STRING']);

// Select page
switch ($qs[0]) {
	case '':
		// Home
		$latest_mp = mysql_fetch_row(mysql_query(sprintf('SELECT mp_photo.*, mp.name FROM mp_photo, mp WHERE mp_photo.mp_id = mp.id ORDER BY id DESC LIMIT 1')));
		$latest_lord = mysql_fetch_row(mysql_query(sprintf('SELECT lord_photo.*, lord.name FROM lord_photo, lord WHERE lord_photo.lord_id = lord.id ORDER BY id DESC LIMIT 1')));
		$latest_msp = mysql_fetch_row(mysql_query(sprintf('SELECT msp_photo.*, msp.name FROM msp_photo, msp WHERE msp_photo.msp_id = msp.id ORDER BY id DESC LIMIT 1')));
		$latest_mla = mysql_fetch_row(mysql_query(sprintf('SELECT mla_photo.*, mla.name FROM mla_photo, mla WHERE mla_photo.mla_id = mla.id ORDER BY id DESC LIMIT 1')));
		$latest_aus_rep = mysql_fetch_row(mysql_query(sprintf('SELECT aus_rep_photo.*, aus_rep.name FROM aus_rep_photo, aus_rep WHERE aus_rep_photo.aus_rep_id = aus_rep.id ORDER BY id DESC LIMIT 1')));
		$latest_aus_sen = mysql_fetch_row(mysql_query(sprintf('SELECT aus_sen_photo.*, aus_sen.name FROM aus_sen_photo, aus_sen WHERE aus_sen_photo.aus_sen_id = aus_sen.id ORDER BY id DESC LIMIT 1')));
		echo '<h2>Welcome to FaceMyMP</h2><p><strong>FaceMyMP</strong> allows you to view and upload photos of politicians, which include UK <em>Members of Parliament</em>, <em>Lords</em>, <em>Members of the Scottish Parliament</em> and <em>Members of the Legislative Assembly of Northern Ireland</em> as well as Australian <em>Representatives</em> and <em>Senators</em> on this site.</p><h3>Latest photos</h3><div id="latestphotos">';
		echo '<a href="/mp?id='.$latest_mp[1].'"><img src="'.$uploadurl.'/mp/'.$latest_mp[1].'_'.$latest_mp[2].'.jpg" width="100" alt="'.$latest_mp[4].'" title="'.$latest_mp[4].'"></a>';
		echo '<a href="/lord?id='.$latest_lord[1].'"><img src="'.$uploadurl.'/lord/'.$latest_lord[1].'_'.$latest_lord[2].'.jpg" width="100" alt="'.$latest_lord[4].'" title="'.$latest_lord[4].'"></a>';
		echo '<a href="/msp?id='.$latest_msp[1].'"><img src="'.$uploadurl.'/msp/'.$latest_msp[1].'_'.$latest_msp[2].'.jpg" width="100" alt="'.$latest_msp[4].'" title="'.$latest_msp[4].'"></a>';
		echo '<a href="/mla?id='.$latest_mla[1].'"><img src="'.$uploadurl.'/mla/'.$latest_mla[1].'_'.$latest_mla[2].'.jpg" width="100" alt="'.$latest_mla[4].'" title="'.$latest_mla[4].'"></a>';
		echo '<a href="/aus_rep?id='.$latest_aus_rep[1].'"><img src="'.$uploadurl.'/aus_rep/'.$latest_aus_rep[1].'_'.$latest_aus_rep[2].'.jpg" width="100" alt="'.$latest_aus_rep[4].'" title="'.$latest_aus_rep[4].'"></a>';
		echo '<a href="/aus_sen?id='.$latest_aus_sen[1].'"><img src="'.$uploadurl.'/aus_sen/'.$latest_aus_sen[1].'_'.$latest_aus_sen[2].'.jpg" width="100" alt="'.$latest_aus_sen[4].'" title="'.$latest_aus_sen[4].'"></a>';
		echo '</div>';
		break;
	case 'mp':
		// MP
		echo '<h2>MPs</h2>';
		if (isset($_REQUEST['id'])) {
			// Get details of MP
			$query = sprintf('SELECT * FROM mp WHERE id = %u', mysql_real_escape_string($_REQUEST['id']));
			$result = mysql_query($query);
			if (mysql_num_rows($result) > 0) {
				$row = mysql_fetch_row($result);
				echo '<p><strong>' . $row[1] . '</strong> (' . str_replace('&', '&amp;', $row[2]) . ', ' . (($row[4] == 0) ? '<strong><em>formerly</em></strong> ' : '') . str_replace('&', '&amp;', $row[3]) . ')</p>';
				$query = sprintf('SELECT * FROM mp_photo WHERE mp_id = %u', mysql_real_escape_string($_REQUEST['id']));
				$result = mysql_query($query);
				if (mysql_num_rows($result) > 0) {
					echo '<p>Here are photos of this MP (click a photo to see the full-size version):</p>';
					while ($row = mysql_fetch_array($result)) {
						echo '<span class="photo"><span class="selectphoto"><a href="'.$uploadurl.'/mp/' . $row[1] . '_' . $row[2] . '.jpg" rel="lightbox['.$row[1].']" title="' . $row[3] . '"><img src="'.$uploadurl.'/mp/' . $row[1] . '_' . $row[2] . '.jpg" width="100" alt=""></a></span><br><span class="reportphoto"><a href="/report?resource=photo&amp;type=mp&amp;id=' . $row[1] . '&amp;guid=' . $row[2] . '">Report this photo</a></span>';
						if (isset($_SESSION['loggedin']) && $_SESSION['level'] >= 2) {
							echo '<br><span class="deletephoto"><a href="#" onclick="deletePhoto(\'mp\', ' . $row[0] . ', \'mp/' . $row[1] . '_' . $row[2] . '.jpg\', \'' . md5($secret . 'mp/' . $row[1] . '_' . $row[2] . '.jpg') . '\', \'' . $_SERVER['REQUEST_URI'] . '\'); return false">Delete this photo</a></span>';
						}
						echo '</span>';
					}
					echo '<div class="cleannclear"></div>';
				} else {
					echo '<p>There are currently no photos of this MP.</p>';
				}
				if ($_UPLOADS) {
					echo '<form action="/upload" method="post" enctype="multipart/form-data"><fieldset class="upload"><legend>Upload a photo</legend><input type="hidden" name="type" value="mp"><input type="hidden" name="id" value="' . $_REQUEST['id'] . '"><input type="file" name="uploadfile"><br><label for="attrib">Attribution:</label> <input type="text" name="attrib" size="30" maxlength="255" id="attrib"><br><input type="checkbox" name="abide" value="1" id="abide"> <label for="abide">I confirm that I am allowed to upload this photo.</label><br><input type="submit" value="Upload"></fieldset></form>';
				}
			} else {
				// MP doesn't exist
				echo '<p>An MP with this ID doesn\'t exist.</p>';
			}
		} else {
			echo '<p>To get photos of MPs, choose the name or constituency of the MP from the lists below, or enter your postcode to find your local MP.</p>';
			echo '<form action="/mp" method="get"><fieldset><legend>MPs by name</legend><select name="id" id="mp"><option value="">Choose an MP</option><optgroup label="Active">';
			$query1 = 'SELECT mp.id, mp.name, mp.constituency FROM mp WHERE mp.active = 1 ORDER BY mp.name ASC';
			$result1 = mysql_query($query1);
			$query2 = 'SELECT mp.id, mp.name, mp.constituency FROM mp WHERE mp.active = 0 ORDER BY mp.name ASC';
			$result2 = mysql_query($query2);
			while ($row = mysql_fetch_row($result1)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . ' (' . str_replace('&', '&amp;', $row[2]) . ')</option>';
			}
			echo '</optgroup><optgroup label="Former">';
			while ($row = mysql_fetch_row($result2)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . ' (' . str_replace('&', '&amp;', $row[2]) . ')</option>';
			}
			echo '</optgroup></select>&nbsp;<input type="submit" value="Get photos"></fieldset></form>';
			echo '<form action="/mp" method="get"><fieldset><legend>MPs by constituency</legend><select name="id" id="constituency"><option value="">Choose a constituency</option><optgroup label="Active">';
			$query1 = 'SELECT mp.id, mp.name, mp.constituency FROM mp WHERE mp.active = 1 ORDER BY mp.constituency ASC';
			$result1 = mysql_query($query1);
			$query2 = 'SELECT mp.id, mp.name, mp.constituency FROM mp WHERE mp.active = 0 ORDER BY mp.constituency ASC';
			$result2 = mysql_query($query2);
			while ($row = mysql_fetch_row($result1)) {
				echo '<option value="' . $row[0] . '">' . str_replace('&', '&amp;', $row[2]) . ' (' . $row[1] . ')</option>';
			}
			echo '</optgroup><optgroup label="Former">';
			while ($row = mysql_fetch_row($result2)) {
				echo '<option value="' . $row[0] . '">' . str_replace('&', '&amp;', $row[2]) . ' (' . $row[1] . ')</option>';
			}
			echo '</optgroup></select>&nbsp;<input type="submit" value="Get photos"></fieldset></form>';
			echo '<form action="/findmp" method="get"><fieldset><legend>MP by postcode</legend><label for="postcode">Postcode:</label> <input type="text" name="postcode" id="postcode" size="10"> <input type="submit" value="Get photos"></fieldset></form>';
		}
		break;
	case 'lord':
		// Lords
		echo '<h2>Lords</h2>';
		if (isset($_REQUEST['id'])) {
			// Get details of Lord
			$query = sprintf('SELECT * FROM lord WHERE id = %u', mysql_real_escape_string($_REQUEST['id']));
			$result = mysql_query($query);
			if (mysql_num_rows($result) > 0) {
				$row = mysql_fetch_row($result);
				echo '<p><strong>' . $row[1] . '</strong> (' . str_replace('&', '&amp;', $row[2]) . (($row[3] == 0) ? ', <strong><em>former Peer</em></strong>' : '') . ')</p>';
				$query = sprintf('SELECT * FROM lord_photo WHERE lord_id = %u', mysql_real_escape_string($_REQUEST['id']));
				$result = mysql_query($query);
				if (mysql_num_rows($result) > 0) {
					echo '<p>Here are photos of this Lord (click a photo to see the full-size version):</p>';
					while ($row = mysql_fetch_array($result)) {
						echo '<span class="photo"><span class="selectphoto"><a href="'.$uploadurl.'/lord/' . $row[1] . '_' . $row[2] . '.jpg" rel="lightbox['.$row[1].']" title="' . $row[3] . '"><img src="'.$uploadurl.'/lord/' . $row[1] . '_' . $row[2] . '.jpg" width="100" alt=""></a></span><br><span class="reportphoto"><a href="/report?resource=photo&amp;type=lord&amp;id=' . $row[1] . '&amp;guid=' . $row[2] . '">Report this photo</a></span>';
						if (isset($_SESSION['loggedin']) && $_SESSION['level'] >= 2) {
							echo '<br><span class="deletephoto"><a href="#" onclick="deletePhoto(\'lord\', ' . $row[0] . ', \'lord/' . $row[1] . '_' . $row[2] . '.jpg\', \'' . md5($secret . 'lord/' . $row[1] . '_' . $row[2] . '.jpg') . '\', \'' . $_SERVER['REQUEST_URI'] . '\'); return false">Delete this photo</a></span>';
						}
						echo '</span>';
					}
					echo '<div class="cleannclear"></div>';
				} else {
					echo '<p>There are currently no photos of this Lord.</p>';
				}
				if ($_UPLOADS) {
					echo '<form action="/upload" method="post" enctype="multipart/form-data"><fieldset class="upload"><legend>Upload a photo</legend><input type="hidden" name="type" value="lord"><input type="hidden" name="id" value="' . $_REQUEST['id'] . '"><input type="file" name="uploadfile"><br><label for="attrib">Attribution:</label> <input type="text" name="attrib" size="30" maxlength="255" id="attrib"><br><input type="checkbox" name="abide" value="1" id="abide"> <label for="abide">I confirm that I am allowed to upload this photo.</label><br><input type="submit" value="Upload"></fieldset></form>';
				}
			} else {
				// Lord doesn't exist
				echo '<p>A Lord with this ID doesn\'t exist.</p>';
			}
		} else {
			echo '<p>To get photos of Lords, choose the name or party of the Lord from the list below.</p>';
			echo '<form action="/lord" method="get"><fieldset><legend>Lords by name</legend><select name="id" id="lord"><option value="">Choose a Lord</option><optgroup label="Active">';
			$query1 = 'SELECT lord.id, lord.name FROM lord WHERE lord.active = 1 ORDER BY lord.name ASC';
			$result1 = mysql_query($query1);
			$query2 = 'SELECT lord.id, lord.name FROM lord WHERE lord.active = 0 ORDER BY lord.name ASC';
			$result2 = mysql_query($query2);
			while ($row = mysql_fetch_row($result1)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . '</option>';
			}
			echo '</optgroup><optgroup label="Former">';
			while ($row = mysql_fetch_row($result2)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . '</option>';
			}
			echo '</optgroup></select>&nbsp;<input type="submit" value="Get photos"></fieldset></form>';
			echo '<form action="/lord" method="get"><fieldset><legend>Lords by party</legend><select name="id" id="party"><option value="">Choose a Lord</option><optgroup label="Active">';
			$query1 = 'SELECT lord.id, lord.name, lord.party FROM lord WHERE lord.active = 1 ORDER BY lord.party ASC, lord.name ASC';
			$result1 = mysql_query($query1);
			$query2 = 'SELECT lord.id, lord.name, lord.party FROM lord WHERE lord.active = 0 ORDER BY lord.party ASC, lord.name ASC';
			$result2 = mysql_query($query2);
			while ($row = mysql_fetch_row($result1)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . ' (' . $row[2] . ')</option>';
			}
			echo '</optgroup><optgroup label="Former">';
			while ($row = mysql_fetch_row($result2)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . ' (' . $row[2] . ')</option>';
			}
			echo '</optgroup></select>&nbsp;<input type="submit" value="Get photos"></fieldset></form>';
		}
		break;
	case 'msp':
		// MSP
		echo '<h2>MSPs</h2>';
		if (isset($_REQUEST['id'])) {
			// Get details of MSP
			$query = sprintf('SELECT * FROM msp WHERE id = %u', mysql_real_escape_string($_REQUEST['id']));
			$result = mysql_query($query);
			if (mysql_num_rows($result) > 0) {
				$row = mysql_fetch_row($result);
				echo '<p><strong>' . $row[1] . '</strong> (' . str_replace('&', '&amp;', $row[2]) . ', ' . (($row[4] == 0) ? '<strong><em>formerly</em></strong> ' : '') . str_replace('&', '&amp;', $row[3]) . ')</p>';
				$query = sprintf('SELECT * FROM msp_photo WHERE msp_id = %u', mysql_real_escape_string($_REQUEST['id']));
				$result = mysql_query($query);
				if (mysql_num_rows($result) > 0) {
					echo '<p>Here are photos of this MSP (click a photo to see the full-size version):</p>';
					while ($row = mysql_fetch_array($result)) {
						echo '<span class="photo"><span class="selectphoto"><a href="'.$uploadurl.'/msp/' . $row[1] . '_' . $row[2] . '.jpg" rel="lightbox['.$row[1].']" title="' . $row[3] . '"><img src="'.$uploadurl.'/msp/' . $row[1] . '_' . $row[2] . '.jpg" width="100" alt=""></a></span><br><span class="reportphoto"><a href="/report?resource=photo&amp;type=msp&amp;id=' . $row[1] . '&amp;guid=' . $row[2] . '">Report this photo</a></span>';
						if (isset($_SESSION['loggedin']) && $_SESSION['level'] >= 2) {
							echo '<br><span class="deletephoto"><a href="#" onclick="deletePhoto(\'msp\', ' . $row[0] . ', \'msp/' . $row[1] . '_' . $row[2] . '.jpg\', \'' . md5($secret . 'msp/' . $row[1] . '_' . $row[2] . '.jpg') . '\', \'' . $_SERVER['REQUEST_URI'] . '\'); return false">Delete this photo</a></span>';
						}
						echo '</span>';
					}
					echo '<div class="cleannclear"></div>';
				} else {
					echo '<p>There are currently no photos of this MSP.</p>';
				}
				if ($_UPLOADS) {
					echo '<form action="/upload" method="post" enctype="multipart/form-data"><fieldset class="upload"><legend>Upload a photo</legend><input type="hidden" name="type" value="msp"><input type="hidden" name="id" value="' . $_REQUEST['id'] . '"><input type="file" name="uploadfile"><br><label for="attrib">Attribution:</label> <input type="text" name="attrib" size="30" maxlength="255" id="attrib"><br><input type="checkbox" name="abide" value="1" id="abide"> <label for="abide">I confirm that I am allowed to upload this photo.</label><br><input type="submit" value="Upload"></fieldset></form>';
				}
			} else {
				// MSP doesn't exist
				echo '<p>An MSP with this ID doesn\'t exist.</p>';
			}
		} else {
			echo '<p>To get photos of MSPs, choose the name of the MSP from the list below.</p>';
			echo '<form action="/msp" method="get"><fieldset><legend>MSPs by name</legend><select name="id" id="msp"><option value="">Choose an MSP</option><optgroup label="Active">';
			$query1 = 'SELECT msp.id, msp.name FROM msp WHERE msp.active = 1 ORDER BY msp.name ASC';
			$result1 = mysql_query($query1);
			$query2 = 'SELECT msp.id, msp.name FROM msp WHERE msp.active = 0 ORDER BY msp.name ASC';
			$result2 = mysql_query($query2);
			while ($row = mysql_fetch_row($result1)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . '</option>';
			}
			echo '</optgroup><optgroup label="Former">';
			while ($row = mysql_fetch_row($result2)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . '</option>';
			}
			echo '</optgroup></select>&nbsp;<input type="submit" value="Get photos"></fieldset></form>';
		}
		break;
	case 'mla':
		// MLA
		echo '<h2>MLAs</h2>';
		if (isset($_REQUEST['id'])) {
			// Get details of MLA
			$query = sprintf('SELECT * FROM mla WHERE id = %u', mysql_real_escape_string($_REQUEST['id']));
			$result = mysql_query($query);
			if (mysql_num_rows($result) > 0) {
				$row = mysql_fetch_row($result);
				echo '<p><strong>' . $row[1] . '</strong> (' . str_replace('&', '&amp;', $row[2]) . ', ' . (($row[4] == 0) ? '<strong><em>formerly</em></strong> ' : '') . str_replace('&', '&amp;', $row[3]) . ')</p>';
				$query = sprintf('SELECT * FROM mla_photo WHERE mla_id = %u', mysql_real_escape_string($_REQUEST['id']));
				$result = mysql_query($query);
				if (mysql_num_rows($result) > 0) {
					echo '<p>Here are photos of this MLA (click a photo to see the full-size version):</p>';
					while ($row = mysql_fetch_array($result)) {
						echo '<span class="photo"><span class="selectphoto"><a href="'.$uploadurl.'/mla/' . $row[1] . '_' . $row[2] . '.jpg" rel="lightbox['.$row[1].']" title="' . $row[3] . '"><img src="'.$uploadurl.'/mla/' . $row[1] . '_' . $row[2] . '.jpg" width="100" alt=""></a></span><br><span class="reportphoto"><a href="/report?resource=photo&amp;type=mla&amp;id=' . $row[1] . '&amp;guid=' . $row[2] . '">Report this photo</a></span>';
						if (isset($_SESSION['loggedin']) && $_SESSION['level'] >= 2) {
							echo '<br><span class="deletephoto"><a href="#" onclick="deletePhoto(\'mla\', ' . $row[0] . ', \'mla/' . $row[1] . '_' . $row[2] . '.jpg\', \'' . md5($secret . 'mla/' . $row[1] . '_' . $row[2] . '.jpg') . '\', \'' . $_SERVER['REQUEST_URI'] . '\'); return false">Delete this photo</a></span>';
						}
						echo '</span>';
					}
					echo '<div class="cleannclear"></div>';
				} else {
					echo '<p>There are currently no photos of this MLA.</p>';
				}
				if ($_UPLOADS) {
					echo '<form action="/upload" method="post" enctype="multipart/form-data"><fieldset class="upload"><legend>Upload a photo</legend><input type="hidden" name="type" value="mla"><input type="hidden" name="id" value="' . $_REQUEST['id'] . '"><input type="file" name="uploadfile"><br><label for="attrib">Attribution:</label> <input type="text" name="attrib" size="30" maxlength="255" id="attrib"><br><input type="checkbox" name="abide" value="1" id="abide"> <label for="abide">I confirm that I am allowed to upload this photo.</label><br><input type="submit" value="Upload"></fieldset></form>';
				}
			} else {
				// MLA doesn't exist
				echo '<p>An MLA with this ID doesn\'t exist.</p>';
			}
		} else {
			echo '<p>To get photos of MLAs, choose the name of the MLA from the list below.</p>';
			echo '<form action="/mla" method="get"><fieldset><legend>MLAs by name</legend><select name="id" id="mla"><option value="">Choose an MLA</option><optgroup label="Active">';
			$query1 = 'SELECT mla.id, mla.name FROM mla WHERE mla.active = 1 ORDER BY name ASC';
			$result1 = mysql_query($query1);
			$query2 = 'SELECT mla.id, mla.name FROM mla WHERE mla.active = 0 ORDER BY name ASC';
			$result2 = mysql_query($query2);
			while ($row = mysql_fetch_row($result1)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . '</option>';
			}
			echo '</optgroup><optgroup label="Former">';
			while ($row = mysql_fetch_row($result2)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . '</option>';
			}
			echo '</optgroup></select>&nbsp;<input type="submit" value="Get photos"></fieldset></form>';
		}
		break;
	case 'findmp':
		// Find an MP
		echo '<h2>Find an MP</h2>';
		if (isset($_REQUEST['postcode']) && trim($_REQUEST['postcode']) != '') {
			$result = unserialize(file_get_contents('http://www.theyworkforyou.com/api/getMP?key=' . $twfy_apikey . '&output=php&postcode=' . urlencode($_REQUEST['postcode'])));
			if (isset($result['person_id'])) {
				// Not the best way to do it, but oh well...
				echo '<script type="text/javascript">window.location.replace(\'/mp?id=' . $result['person_id'] . '\');</script>';
			} else {
				echo '<p>The postcode you provided was not recognised.</p>';
			}
		} else {
			echo '<p>You must provide a postcode to find an MP.</p>';
		}
		break;
	case 'aus_rep':
		// Representatives (Australia)
		echo '<h2>Representatives (Australia)</h2>';
		if (isset($_REQUEST['id'])) {
			// Get details of Representative
			$query = sprintf('SELECT * FROM aus_rep WHERE id = %u', mysql_real_escape_string($_REQUEST['id']));
			$result = mysql_query($query);
			if (mysql_num_rows($result) > 0) {
				$row = mysql_fetch_row($result);
				echo '<p><strong>' . $row[1] . '</strong> (' . str_replace('&', '&amp;', $row[2]) . ', ' . (($row[4] == 0) ? '<strong><em>formerly</em></strong> ' : '') . str_replace('&', '&amp;', $row[3]) . ')</p>';
				$query = sprintf('SELECT * FROM aus_rep_photo WHERE aus_rep_id = %u', mysql_real_escape_string($_REQUEST['id']));
				$result = mysql_query($query);
				if (mysql_num_rows($result) > 0) {
					echo '<p>Here are photos of this Representative (click a photo to see the full-size version):</p>';
					while ($row = mysql_fetch_array($result)) {
						echo '<span class="photo"><span class="selectphoto"><a href="'.$uploadurl.'/aus_rep/' . $row[1] . '_' . $row[2] . '.jpg" rel="lightbox['.$row[1].']" title="' . $row[3] . '"><img src="'.$uploadurl.'/aus_rep/' . $row[1] . '_' . $row[2] . '.jpg" width="100" alt=""></a></span><br><span class="reportphoto"><a href="/report?resource=photo&amp;type=aus_rep&amp;id=' . $row[1] . '&amp;guid=' . $row[2] . '">Report this photo</a></span>';
						if (isset($_SESSION['loggedin']) && $_SESSION['level'] >= 2) {
							echo '<br><span class="deletephoto"><a href="#" onclick="deletePhoto(\'aus_rep\', ' . $row[0] . ', \'aus_rep/' . $row[1] . '_' . $row[2] . '.jpg\', \'' . md5($secret . 'aus_rep/' . $row[1] . '_' . $row[2] . '.jpg') . '\', \'' . $_SERVER['REQUEST_URI'] . '\'); return false">Delete this photo</a></span>';
						}
						echo '</span>';
					}
					echo '<div class="cleannclear"></div>';
				} else {
					echo '<p>There are currently no photos of this Representative.</p>';
				}
				if ($_UPLOADS) {
					echo '<form action="/upload" method="post" enctype="multipart/form-data"><fieldset class="upload"><legend>Upload a photo</legend><input type="hidden" name="type" value="aus_rep"><input type="hidden" name="id" value="' . $_REQUEST['id'] . '"><input type="file" name="uploadfile"><br><label for="attrib">Attribution:</label> <input type="text" name="attrib" size="30" maxlength="255" id="attrib"><br><input type="checkbox" name="abide" value="1" id="abide"> <label for="abide">I confirm that I am allowed to upload this photo.</label><br><input type="submit" value="Upload"></fieldset></form>';
				}
			} else {
				// Representative doesn't exist
				echo '<p>A Representative with this ID doesn\'t exist.</p>';
			}
		} else {
			echo '<p>To get photos of Representatives, choose the name or constituency of the Representative from the lists below.</p>';
			echo '<form action="/aus_rep" method="get"><fieldset><legend>Representatives by name</legend><select name="id" id="rep"><option value="">Choose a Representative</option><optgroup label="Active">';
			$query1 = 'SELECT aus_rep.id, aus_rep.name, aus_rep.constituency FROM aus_rep WHERE aus_rep.active = 1 ORDER BY aus_rep.name ASC';
			$result1 = mysql_query($query1);
			$query2 = 'SELECT aus_rep.id, aus_rep.name, aus_rep.constituency FROM aus_rep WHERE aus_rep.active = 0 ORDER BY aus_rep.name ASC';
			$result2 = mysql_query($query2);
			while ($row = mysql_fetch_row($result1)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . ' (' . str_replace('&', '&amp;', $row[2]) . ')</option>';
			}
			echo '</optgroup><optgroup label="Former">';
			while ($row = mysql_fetch_row($result2)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . ' (' . str_replace('&', '&amp;', $row[2]) . ')</option>';
			}
			echo '</optgroup></select>&nbsp;<input type="submit" value="Get photos"></fieldset></form>';
			echo '<form action="/aus_rep" method="get"><fieldset><legend>Representatives by constituency</legend><select name="id" id="constituency"><option value="">Choose a constituency</option><optgroup label="Active">';
			$query1 = 'SELECT aus_rep.id, aus_rep.name, aus_rep.constituency FROM aus_rep WHERE aus_rep.active = 1 ORDER BY aus_rep.constituency ASC';
			$result1 = mysql_query($query1);
			$query2 = 'SELECT aus_rep.id, aus_rep.name, aus_rep.constituency FROM aus_rep WHERE aus_rep.active = 0 ORDER BY aus_rep.constituency ASC';
			$result2 = mysql_query($query2);
			while ($row = mysql_fetch_row($result1)) {
				echo '<option value="' . $row[0] . '">' . str_replace('&', '&amp;', $row[2]) . ' (' . $row[1] . ')</option>';
			}
			echo '</optgroup><optgroup label="Former">';
			while ($row = mysql_fetch_row($result2)) {
				echo '<option value="' . $row[0] . '">' . str_replace('&', '&amp;', $row[2]) . ' (' . $row[1] . ')</option>';
			}
			echo '</optgroup></select>&nbsp;<input type="submit" value="Get photos"></fieldset></form>';
		}
		break;
	case 'aus_sen':
		// Senators (Australia)
		echo '<h2>Senators (Australia)</h2>';
		if (isset($_REQUEST['id'])) {
			// Get details of Senator
			$query = sprintf('SELECT * FROM aus_sen WHERE id = %u', mysql_real_escape_string($_REQUEST['id']));
			$result = mysql_query($query);
			if (mysql_num_rows($result) > 0) {
				$row = mysql_fetch_row($result);
				echo '<p><strong>' . $row[1] . '</strong> (' . str_replace('&', '&amp;', $row[2]) . (($row[3] == 0) ? ', <strong><em>former Senator</em></strong>' : '') . ')</p>';
				$query = sprintf('SELECT * FROM aus_sen_photo WHERE aus_sen_id = %u', mysql_real_escape_string($_REQUEST['id']));
				$result = mysql_query($query);
				if (mysql_num_rows($result) > 0) {
					echo '<p>Here are photos of this Senator (click a photo to see the full-size version):</p>';
					while ($row = mysql_fetch_array($result)) {
						echo '<span class="photo"><span class="selectphoto"><a href="'.$uploadurl.'/aus_sen/' . $row[1] . '_' . $row[2] . '.jpg" rel="lightbox['.$row[1].']" title="' . $row[3] . '"><img src="'.$uploadurl.'/aus_sen/' . $row[1] . '_' . $row[2] . '.jpg" width="100" alt=""></a></span><br><span class="reportphoto"><a href="/report?resource=photo&amp;type=aus_sen&amp;id=' . $row[1] . '&amp;guid=' . $row[2] . '">Report this photo</a></span>';
						if (isset($_SESSION['loggedin']) && $_SESSION['level'] >= 2) {
							echo '<br><span class="deletephoto"><a href="#" onclick="deletePhoto(\'aus_sen\', ' . $row[0] . ', \'aus_sen/' . $row[1] . '_' . $row[2] . '.jpg\', \'' . md5($secret . 'aus_sen/' . $row[1] . '_' . $row[2] . '.jpg') . '\', \'' . $_SERVER['REQUEST_URI'] . '\'); return false">Delete this photo</a></span>';
						}
						echo '</span>';
					}
					echo '<div class="cleannclear"></div>';
				} else {
					echo '<p>There are currently no photos of this Senator.</p>';
				}
				if ($_UPLOADS) {
					echo '<form action="/upload" method="post" enctype="multipart/form-data"><fieldset class="upload"><legend>Upload a photo</legend><input type="hidden" name="type" value="aus_sen"><input type="hidden" name="id" value="' . $_REQUEST['id'] . '"><input type="file" name="uploadfile"><br><label for="attrib">Attribution:</label> <input type="text" name="attrib" size="30" maxlength="255" id="attrib"><br><input type="checkbox" name="abide" value="1" id="abide"> <label for="abide">I confirm that I am allowed to upload this photo.</label><br><input type="submit" value="Upload"></fieldset></form>';
				}
			} else {
				// Senator doesn't exist
				echo '<p>A Senator with this ID doesn\'t exist.</p>';
			}
		} else {
			echo '<p>To get photos of Senators, choose the name of the Senator from the list below.</p>';
			echo '<form action="/aus_sen" method="get"><fieldset><legend>Senators by name</legend><select name="id" id="sen"><option value="">Choose a Senator</option><optgroup label="Active">';
			$query1 = 'SELECT aus_sen.id, aus_sen.name FROM aus_sen WHERE aus_sen.active = 1 ORDER BY aus_sen.name ASC';
			$result1 = mysql_query($query1);
			$query2 = 'SELECT aus_sen.id, aus_sen.name FROM aus_sen WHERE aus_sen.active = 0 ORDER BY aus_sen.name ASC';
			$result2 = mysql_query($query2);
			while ($row = mysql_fetch_row($result1)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . '</option>';
			}
			echo '</optgroup><optgroup label="Former">';
			while ($row = mysql_fetch_row($result2)) {
				echo '<option value="' . $row[0] . '">' . $row[1] . '</option>';
			}
			echo '</optgroup></select>&nbsp;<input type="submit" value="Get photos"></fieldset></form>';
		}
		break;
	case 'upload':
		// Upload a photo
		echo '<h2>Upload a photo</h2>';
		if (!$_UPLOADS) {
			echo '<p><strong>ERROR:</strong> Uploads are currently disabled. Please try again later.</p>';
			break;
		}
		if (isset($_FILES['uploadfile']) && $_FILES['uploadfile']['error'] == 0 && $_FILES['uploadfile']['size'] <= 2097152 && ($_FILES['uploadfile']['type'] == 'image/jpg' || $_FILES['uploadfile']['type'] == 'image/jpeg' || $_FILES['uploadfile']['type'] == 'image/pjpeg') && isset($_POST['type']) && isset($_POST['id'])) {
			if (!isset($_REQUEST['abide']) || $_REQUEST['abide'] != '1') {
				// User hasn't agreed to be responsible for the photo
				echo '<p>You must confirm that you are allowed to upload this photo.</p>';
				break;
			}
			// Upload photo
			// Generate a GUID
			$guid = sprintf('%04x%04x%04x%04x%04x%04x%04x%04x', mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0x0fff) | 0x4000, mt_rand(0, 0x3fff) | 0x8000, mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff));
			// Check type
			switch ($_POST['type']) {
				case 'mp':
					$type = 'mp';
					break;
				case 'lord':
					$type = 'lord';
					break;
				case 'msp':
					$type = 'msp';
					break;
				case 'mla':
					$type = 'mla';
					break;
				case 'aus_rep':
					$type = 'aus_rep';
					break;
				case 'aus_sen':
					$type = 'aus_sen';
					break;
				default:
					$type = '';
					break;
			}
			if ($type != '') {
				$uploaddir .= $type . '/';
				// Check ID
				$query = sprintf('SELECT id FROM %s WHERE id = %u', $type, mysql_real_escape_string($_POST['id']));
				$result = mysql_query($query);
				if (mysql_num_rows($result) > 0) {
					// Go ahead and upload the file
					$query = sprintf('INSERT INTO unapproved_photo (`person_id`,`type`,`guid`,`attrib`) VALUES (%u,"%s","%s","%s")', mysql_real_escape_string($_POST['id']), $type, $guid, mysql_real_escape_string($_POST['attrib']));
					$result = mysql_query($query);
					if (mysql_affected_rows() > 0) {
						move_uploaded_file($_FILES['uploadfile']['tmp_name'], $uploaddir . $_POST['id'] . '_' . $guid . '.jpg');
						echo '<p>Thank you for uploading a photo. Your photo will appear on the site after it is approved.</p>';
					} else {
						// Error while moving uploaded file
						echo '<p><strong>ERROR:</strong> An error occurred while uploading the photo.</p>';
					}
				} else {
					// Invalid ID
					echo '<p><strong>ERROR:</strong> An invalid ID was provided.</p>';
				}
			} else {
				// Invalid type
				echo '<p><strong>ERROR:</strong> An invalid type was provided.</p>';
			}
		} else {
			// Various errors!
			echo '<p><strong>ERROR:</strong> An error occurred while uploading the photo. Possible errors could be:</p><ul><li>An invalid person ID was provided.</li><li>An invalid politician type was provided.</li><li>No file was selected.</li><li>The uploaded file is too large (more than 2 megabytes).</li><li>The uploaded file is of the wrong type (only JPEG files are currently accepted).</li></ul>';
		}
		break;
	case 'about':
		// About
		$stat_mp = mysql_fetch_row(mysql_query(sprintf('SELECT COUNT(*) FROM mp')));
		$stat_lord = mysql_fetch_row(mysql_query(sprintf('SELECT COUNT(*) FROM lord')));
		$stat_msp = mysql_fetch_row(mysql_query(sprintf('SELECT COUNT(*) FROM msp')));
		$stat_mla = mysql_fetch_row(mysql_query(sprintf('SELECT COUNT(*) FROM mla')));
		$stat_aus_rep = mysql_fetch_row(mysql_query(sprintf('SELECT COUNT(*) FROM aus_rep')));
		$stat_aus_sen = mysql_fetch_row(mysql_query(sprintf('SELECT COUNT(*) FROM aus_sen')));
		echo '<h2>About</h2><p>Write some information about the site here.</p><h3>Statistics</h3><p>On this site, there are:</p><ul><li>'.$stat_mp[0].' Members of Parliament</li><li>'.$stat_lord[0].' Lords</li><li>'.$stat_msp[0].' Members of the Scottish Parliament</li><li>'.$stat_mla[0].' Members of the Legislative Assembly of Northern Ireland</li><li>'.$stat_aus_rep[0].' Australian Representatives</li><li>'.$stat_aus_sen[0].' Australian Senators</li></ul>';
		break;
	case 'contact':
		// Contact
		if (isset($_POST['postback']) && $_POST['postback'] == 'doContact') {
			$contactErrorName = false;
			$contactErrorEmail = false;
			$contactErrorMessage = false;
			if (!isset($_POST['name']) || trim($_POST['name']) == '') {
				$contactErrorName = true;
			}
			if (!isset($_POST['email']) || trim($_POST['email']) == '') {
				$contactErrorEmail = true;
			}
			if (!isset($_POST['message']) || trim($_POST['message']) == '') {
				$contactErrorMessage = true;
			}
			if (!$contactErrorName && !$contactErrorEmail && !$contactErrorMessage) {
				$message = 'The following message was sent via the FaceMyMP contact page on '.date('l j F Y').' at '.date('H:i:s').' UTC:'."\n\n".$_POST['message'];
				if (isset($_POST['ref']) && trim($_POST['ref']) != '') {
					$message .= "\n\n".'Reference: '.$_POST['ref'];
				}
				if (isset($_POST['openid']) && trim($_POST['openid']) != '') {
					$message .= "\n\n".'OpenID: '.$_POST['openid'];
				}
				if (mail($contact_recipient, 'FaceMyMP Message', stripslashes($message), 'From: '.trim($_POST['name']).' <'.trim($_POST['email']).'>'."\r\n")) {
					$contactError = false;
				} else {
					$contactError = true;
				}
			}
		}
		echo '<h2>Contact</h2><p>Please fill out the form below to contact us. All fields are compulsory.</p>'.((isset($_POST['postback']) && $_POST['postback'] == 'doContact') ? (($contactError) ? '<p class="error">There was an error submitting your message. Please try again later.</p>' : (($contactErrorName || $contactErrorEmail || $contactErrorMessage) ? '<p class="error">Please fill in the highlighed fields below and re-submit.</p>' : '<p class="note">Your message has been sent.</p>')) : '').'<form action="/contact" method="post"><table><tr><td><label for="name">Name</label></td><td><input type="text" name="name" value="'.((isset($_POST['name'])) ? $_POST['name'] : ((isset($_SESSION['name'])) ? $_SESSION['name'] : '')).'" id="name" size="30"'.((isset($_POST['postback']) && $_POST['postback'] == 'doContact' && $contactErrorName) ? ' class="error"' : '').'></td></tr><tr><td><label for="email">Email</label></td><td><input type="text" name="email" value="'.((isset($_POST['email'])) ? $_POST['email'] : '').'" id="email" size="30"'.((isset($_POST['postback']) && $_POST['postback'] == 'doContact' && $contactErrorEmail) ? ' class="error"' : '').'></td></tr><tr><td style="vertical-align: top;"><label for="message">Message</label></td><td><textarea name="message" id="message" rows="10" cols="40"'.((isset($_POST['postback']) && $_POST['postback'] == 'doContact' && $contactErrorMessage) ? ' class="error"' : '').'>'.((isset($_POST['message'])) ? stripslashes($_POST['message']) : '').'</textarea></td></tr><tr><td></td><td><input type="hidden" name="ref" value="'.((isset($_REQUEST['ref'])) ? $_REQUEST['ref'] : '').'"><input type="hidden" name="openid" value="'.((isset($_SESSION['id'])) ? $_SESSION['id'] : '').'"><input type="hidden" name="postback" value="doContact"><input type="submit" value="Send my message"></td></tr></table></form>';
		break;
	case 'report':
		// Report a photo
		echo '<h2>Report a photo</h2>';
		if (isset($_REQUEST['resource']) && ($_REQUEST['resource'] == 'photo') && isset($_REQUEST['type']) && $_REQUEST['type'] != '' && isset($_REQUEST['id']) && $_REQUEST['id'] != '' && isset($_REQUEST['guid']) && $_REQUEST['guid'] != '') {
			if (isset($_REQUEST['action'])) {
				if ($_REQUEST['action'] == 'Report') {
					// Report it
					if ($_REQUEST['resource'] == 'photo') {
						$query = sprintf('INSERT INTO report_photo (`person_id`,`type`,`guid`,`comments`) VALUES (%u,"%s","%s","%s")', mysql_real_escape_string($_REQUEST['id']), mysql_real_escape_string($_REQUEST['type']), mysql_real_escape_string($_REQUEST['guid']), mysql_real_escape_string($_REQUEST['comments']));
					}
					mysql_query($query);
					if (mysql_affected_rows() > 0) {
						echo '<p>Your report has been logged and will be acted upon as soon as possible.</p>';
					} else {
						echo '<p>There was an error logging your report. Please try again later.</p>';
					}
				} else {
					// Not the best way to do it, but oh well...
					echo '<script type="text/javascript">history.go(-2);</script>';
				}
			} else {
				// Ask for some comments and confirmation
				echo '<p>If you\'d like to enter some comments about why you\'re reporting this ' . $_REQUEST['resource'] . ', then please do so below. If you\'d like a response, please remember to include your name and email address.</p><form action="/report" method="get"><div><input type="hidden" name="resource" value="' . $_REQUEST['resource'] . '"><input type="hidden" name="type" value="' . $_REQUEST['type'] . '"><input type="hidden" name="id" value="' . $_REQUEST['id'] . '"><input type="hidden" name="guid" value="' . $_REQUEST['guid'] . '"><textarea name="comments" rows="10" cols="40"></textarea><br><br><input type="submit" name="action" value="Report"> <input type="submit" name="action" value="Cancel"></div></form>';
			}
		} else {
			// Invalid query string items
			echo '<p>You need to choose a photo to report.</p>';
		}
		break;
	case 'login':
		// Login
		echo '<h2>Login</h2>';
		if (!$_LOGIN) {
			echo '<p>Sorry, logging in is currently disabled. Please try again later.</p>';
			break;
		}
		if (isset($_GET['token'])) {
			// Get user details
			mysql_select_db($db_database_users) OR die('Could not select database.');
			$user = $rpx->auth_info($_GET['token']);
			$user_name = $user->getElementsByTagName('displayName');
			$user_id = $user->getElementsByTagName('identifier');
			// If everything's not OK, redirect to an error
			if ($user_name->length != 1 || $user_id->length != 1) {
				echo '<script type="text/javascript">window.location.replace(\'/login?error=You+must+provide+at+least+your+name\');</script>';
			}
			// Get the details
			$user_name = $user_name->item(0)->nodeValue;
			$user_id = $user_id->item(0)->nodeValue;
			// Check to see if this user has logged in before
			$query = sprintf('SELECT * FROM user WHERE openid = "%s"', mysql_real_escape_string($user_id));
			$result = mysql_query($query);
			if (mysql_num_rows($result) > 0) {
				// User is already registered - get their details and check to see if their account is enabled
				$row = mysql_fetch_row($result);
				if ($row[3] != 1) {
					// The account is disabled
					echo '<script type="text/javascript">window.location.replace(\'/login?error=Your+account+is+disabled\');</script>';
				} else {
					// Set details
					$_SESSION['loggedin'] = true;
					$_SESSION['id'] = $row[0];
					$_SESSION['name'] = $row[1];
					$_SESSION['level'] = $row[2];
				}
			} else {
				// Register user
				$query = sprintf('INSERT INTO user (`openid`,`name`,`level`,`enabled`) VALUES ("%s","%s",%u,%u)', mysql_real_escape_string($user_id), mysql_real_escape_string($user_name), 0, 1);
				mysql_query($query);
				if (mysql_affected_rows() < 1) {
					echo '<script type="text/javascript">window.location.replace(\'/login?error=Your+details+could+not+be+registered\');</script>';
				} else {
					$_SESSION['loggedin'] = true;
					$_SESSION['id'] = $user_id;
					$_SESSION['name'] = $user_name;
					$_SESSION['level'] = 0;
				}
			}
			// Not the best way to do it, but oh well...
			echo '<script type="text/javascript">window.location.replace(\'' . $_GET['r'] . '\');</script>';
		} else if (isset($_GET['error'])) {
			// Display an error
			echo '<p><strong>Error:</strong> ' . $_GET['error'] . '</p>';
		} else {
			// Not the best way to do it, but oh well...
			echo '<script type="text/javascript">window.location.replace(\'/\');</script>';
		}
		break;
	case 'logout':
		// Logout
		$_SESSION = array();
		if (isset($_COOKIE[session_name()])) {
			setcookie(session_name(), '', time() - 42000, '/');
		}
		@session_destroy();
		// Not the best way to do it, but oh well...
		if (isset($_GET['r'])) {
			echo '<script type="text/javascript">window.location.replace(\'' . $_GET['r'] . '\');</script>';
		} else {
			echo '<script type="text/javascript">window.location.replace(\'/\');</script>';
		}
		break;
	case 'account':
		// Account
		echo '<h2>Account</h2>';
		echo '<script type="text/javascript" src="/scripts/admin/admin.js"></script>';
		mysql_select_db('facemymp_users') OR die('Could not select database.');
		if (!isset($_SESSION['loggedin'])) {
			echo '<p>You must be logged in to view your account details.</p>';
		} else if (isset($_GET['action']) && $_GET['action'] == 'update') {
			if (trim($_POST['name']) != '' && trim($_POST['name']) != $_SESSION['name']) {
				$query = sprintf('UPDATE user SET name = "%s" WHERE openid = "%s"', mysql_real_escape_string(trim($_POST['name'])), mysql_real_escape_string($_SESSION['id']));
				$result = mysql_query($query);
				if (mysql_affected_rows() > 0) {
					$_SESSION['name'] = trim($_POST['name']);
					// Not the best way to do it, but oh well...
					echo '<script type="text/javascript">window.location.replace(\'/account\');</script>';
				} else {
					// Could not update the name
					echo '<p>An error occurred when trying to update your details. Please try again later.</p>';
				}
			} else {
				// Not the best way to do it, but oh well...
				echo '<script type="text/javascript">window.location.replace(\'/account\');</script>';
			}
		} else if (isset($_GET['action']) && $_GET['action'] == 'confirmdelete' && $_SESSION['level'] < 9) {
			// Confirm account deletion
			echo '<p>Are you sure you want to delete your account? This will immediately remove all details from our system. You can register again by logging in with your OpenID.</p><p><a href="/account?action=delete" class="delete">Yes, delete my account</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="/account">No, keep my account</a></p>';
		} else if (isset($_GET['action']) && $_GET['action'] == 'delete' && $_SESSION['level'] < 9) {
			// Delete the account and log the user out
			$query = sprintf('DELETE FROM user WHERE openid = "%s"', mysql_real_escape_string($_SESSION['id']));
			$result = mysql_query($query);
			if (mysql_affected_rows() > 0) {
				// Not the best way to do it, but oh well...
				echo '<script type="text/javascript">window.location.replace(\'/logout\');</script>';
			} else {
				echo '<p>An error occurred when trying to delete your account. Please <a href="/contact">send a message</a> for assistance.</p>';
			}
		} else {
			// Display account details
			$query = sprintf('SELECT * FROM user WHERE openid = "%s"', mysql_real_escape_string($_SESSION['id']));
			$result = mysql_query($query);
			$user = mysql_fetch_row($result);
			echo '<p>You can update your account details here. To change your account level, you need to <a href="/contact">contact us</a>. Your OpenID cannot be changed.</p><form action="/account?action=update" method="post"><table><tr><td>OpenID</td><td>' . $user[0] .'</td></tr><tr><td><label for="name">Name</label></td><td><input type="text" name="name" id="name" size="30" value="' . $user[1] .'"></td></tr><tr><tr><td>Account level</td><td>' . $_accountlevel[$user[2]] . '</td></tr><tr><td colspan="2" style="text-align: center;"><input type="hidden" name="update" value="1"><input type="submit" value="Update my details"></td></tr></table></form>';
			if ($_SESSION['level'] < 9) {
				echo '<p><a href="/account?action=confirmdelete" class="delete">Delete my account</a></p>';
			}
			mysql_select_db('facemymp') OR die('Could not select database.');
			if ($_SESSION['level'] >= 2) {
				// Moderators and higher
				echo '<h2>Moderate</h2>';
				// Photos awaiting approval
				$query = 'SELECT * FROM unapproved_photo ORDER BY id ASC';
				$result = mysql_query($query);
				if (mysql_num_rows($result) > 0) {
					echo '<p>The following photos are awaiting approval:</p><ul>';
					while ($row = mysql_fetch_row($result)) {
						$name = 'SELECT id, name FROM ' . $row[2] . ' WHERE id = ' . $row[1];
						$name = mysql_query($name);
						$name = mysql_fetch_row($name);
						$filename = $row[2] . '/' . $row[1] . '_' . $row[3] . '.jpg';
						echo '<li><a href="' . $uploadurl . '/' . $filename . '" rel="lightbox">' . $name[1] . '</a> ' . ((!empty($row[4])) ? '(' . $row[4] . ')' : '') . ' [<a href="#" onclick="approvePhotoQuick(' . $row[0] . ', \'' . $filename . '\', \'' . str_replace('\'', '\\\'', $name[1]) . '\'); return false">Quick Approve</a>] [<a href="#" onclick="approvePhoto(' . $row[0] . ', \'' . $filename . '\', \'' . str_replace('\'', '\\\'', $name[1]) . '\', \'' . str_replace('\'', '\\\'', $row[4]) . '\'); return false">Approve</a>] [<a href="#" onclick="rejectPhoto(' . $row[0] . ', \'' . $filename . '\', \'' . md5($secret . $filename) . '\', \'' . str_replace('\'', '\\\'', $name[1]) . '\'); return false">Reject</a>]</li>';
					}
					echo '</ul>';
				} else {
					echo '<p>There are no photos awaiting approval.</p>';
				}
			}
			if ($_SESSION['level'] >= 3) {
				// Administrators and higher
				echo '<h2>Administer</h2>';
				$query = 'SELECT * FROM report_photo ORDER BY id ASC';
				$result = mysql_query($query);
				if (mysql_num_rows($result) > 0) {
					echo '<p>The following photos have been reported:</p><ul>';
					while ($row = mysql_fetch_row($result)) {
						$name = 'SELECT id, name FROM ' . $row[2] . ' WHERE id = ' . $row[1];
						$name = mysql_query($name);
						$name = mysql_fetch_row($name);
						$filename = $row[2] . '/' . $row[1] . '_' . $row[3] . '.jpg';
						echo '<li><a href="' . $uploadurl . '/' . $filename . '" rel="lightbox">' . $name[1] . ' (' . $row[0] . ')</a> [<a href="#" onclick="deleteReport(' . $row[0] . ', \'photo\'); return false">Delete report</a>]<br><strong>Comments:</strong> <pre>' . stripslashes($row[4]) . '</pre></li>';
					}
					echo '</ul>';
				} else {
					echo '<p>There are no reported photos.</p>';
				}
				echo '<p>The politician lists were last updated as follows:</p><ul>';
				$admin_updated_dates = mysql_query('SELECT * FROM updates');
				while ($row = mysql_fetch_row($admin_updated_dates)) {
					echo '<li>' . $row[0] . ': ' . $row[1] . ' UTC</li>';
				}
				echo '</ul><p><a href="/account/admin/updatelists">Manually update lists</a></p>';
			}
		}
		break;
	case 'account/admin/approvephoto':
		// Approve a photo
		if (!isset($_SESSION['loggedin'])) {
			echo '<p>You must be logged in to carry out this action.</p>';
		} else if ($_SESSION['level'] >= 2 && isset($_REQUEST['id']) && isset($_REQUEST['name'])) {
			if (isset($_REQUEST['cropped']) && ($_REQUEST['cropped'] == 0 || $_REQUEST['cropped'] == 1)) {
				// Photo has been cropped or skipped cropping; mark as approved
				$query = sprintf('SELECT person_id, type, guid, attrib FROM unapproved_photo WHERE id = %u', mysql_real_escape_string($_REQUEST['id']));
				$type = mysql_query($query);
				$type = mysql_fetch_row($type);
				$query = sprintf('INSERT INTO %s_photo (`%s_id`,`guid`,`attrib`) VALUES (%u,"%s","%s")', $type[1], $type[1], $type[0], $type[2], ((isset($_REQUEST['attrib'])) ? urldecode($_REQUEST['attrib']) : $type[3]));
				mysql_query($query);
				$query = sprintf('DELETE FROM unapproved_photo WHERE id = %u', mysql_real_escape_string($_REQUEST['id']));
				mysql_query($query);
				// Not the best way to do it, but oh well...
				echo '<script type="text/javascript">window.location.replace(\'/account\');</script>';
			} else {
				// Photo needs to be cropped/attribution changed
				echo '<script type="text/javascript" src="/scripts/admin/cropper/cropper.js"></script><h2>Approve photo</h2><p><img src="' . $uploadurl . '/' . $_REQUEST['name'] . '" alt="" id="uploadedPhoto"></p><form action="/account/admin/cropphoto" method="get"><input type="hidden" name="id" value="' . $_REQUEST['id'] . '"><input type="hidden" name="name" value="' . $_REQUEST['name'] . '"><input type="hidden" name="x" id="uploadedPhotoX" value=""><input type="hidden" name="y" id="uploadedPhotoY" value=""><input type="hidden" name="width" id="uploadedPhotoWidth" value=""><input type="hidden" name="height" id="uploadedPhotoHeight" value=""><label for="attrib">Attribution:</label> <input type="text" name="attrib" value="' . ((isset($_REQUEST['attrib'])) ? urldecode($_REQUEST['attrib']) : '') .'" size="30" maxlength="255" id="attrib"><br><input type="submit" value="Crop photo">&nbsp;&nbsp;<input type="submit" name="nocrop" value="Skip cropping">&nbsp;&nbsp;<input type="submit" name="noapprove" value="Cancel"></form><script type="text/javascript">new Cropper.Img(\'uploadedPhoto\', { onEndCrop: function(coords, dimensions) { document.getElementById(\'uploadedPhotoX\').value = coords.x1; document.getElementById(\'uploadedPhotoY\').value = coords.y1; document.getElementById(\'uploadedPhotoWidth\').value = dimensions.width; document.getElementById(\'uploadedPhotoHeight\').value = dimensions.height; } });</script>';
			}
		} else {
			// Not the best way to do it, but oh well...
			echo '<script type="text/javascript">window.location.replace(\'/account\');</script>';
		}
		break;
	case 'account/admin/rejectphoto':
		// Reject a photo
		if (!isset($_SESSION['loggedin'])) {
			echo '<p>You must be logged in to carry out this action.</p>';
		} else if ($_SESSION['level'] >= 2 && isset($_REQUEST['id']) && isset($_REQUEST['name']) && isset($_REQUEST['hash']) && $_REQUEST['hash'] == md5($secret . $_REQUEST['name'])) {
			// This would be *very* dangerous outside a restricted area! We use logins, an MD5 hash and UNIX permissions to protect things a little...
			if (is_file($uploaddir . '/' . $_REQUEST['name'])) {
				unlink($uploaddir . '/' . $_REQUEST['name']);
			}
			$query = sprintf('DELETE FROM unapproved_photo WHERE id = %u', mysql_real_escape_string($_REQUEST['id']));
			mysql_query($query);
		}
		// Not the best way to do it, but oh well...
		echo '<script type="text/javascript">window.location.replace(\'/account\');</script>';
		break;
	case 'account/admin/cropphoto':
		// Crop a photo
		if (!isset($_SESSION['loggedin'])) {
			echo '<p>You must be logged in to carry out this action.</p>';
		} else if ($_SESSION['level'] >= 2) {
			if (!isset($_REQUEST['id']) || !isset($_REQUEST['name']) || !isset($_REQUEST['x']) || !isset($_REQUEST['y']) || !isset($_REQUEST['width']) || !isset($_REQUEST['height']) || $_REQUEST['width'] == 0 || $_REQUEST['height'] == 0) {
				if (isset($_REQUEST['nocrop']) && $_REQUEST['nocrop'] != '') {
					// No cropping required; skip to approval
					// Not the best way to do it, but oh well...
					echo '<script type="text/javascript">window.location.replace(\'/account/admin/approvephoto?id=' . $_REQUEST['id'] . '&name=' . $_REQUEST['name'] . '&attrib=' . urlencode($_REQUEST['attrib']) . '&cropped=0\');</script>';
				} else if (isset($_REQUEST['noapprove']) && $_REQUEST['noapprove'] != '') {
					// Cropping cancelled; return to account
					// Not the best way to do it, but oh well...
					echo '<script type="text/javascript">window.location.replace(\'/account\');</script>';
				} else {
					// Not actually cropped at all
					// Not the best way to do it, but oh well...
					echo '<script type="text/javascript">window.location.replace(\'/account/admin/approvephoto?id=' . $_REQUEST['id'] . '&name=' . $_REQUEST['name'] . '&attrib=' . urlencode($_REQUEST['attrib']) . '&cropped=0\');</script>';
				}
			} else {
				exec('/usr/bin/mogrify -crop ' . escapeshellcmd($_REQUEST['width']) . 'x' . escapeshellcmd($_REQUEST['height']) . '+' . escapeshellcmd($_REQUEST['x']) . '+' . escapeshellcmd($_REQUEST['y']) . ' ' . $uploaddir . '/' . escapeshellcmd($_REQUEST['name']));
				// Not the best way to do it, but oh well...
				echo '<script type="text/javascript">window.location.replace(\'/account/admin/approvephoto?id=' . $_REQUEST['id'] . '&name=' . $_REQUEST['name'] . '&attrib=' . urlencode($_REQUEST['attrib']) . '&cropped=1\');</script>';
			}
		} else {
			// Not the best way to do it, but oh well...
			echo '<script type="text/javascript">window.location.replace(\'/account\');</script>';
		}
		break;
	case 'account/admin/deletephoto':
		// Delete a photo
		if (!isset($_SESSION['loggedin'])) {
			echo '<p>You must be logged in to carry out this action.</p>';
		} else if ($_SESSION['level'] >= 2 && isset($_REQUEST['type']) && isset($_REQUEST['id']) && isset($_REQUEST['name']) && isset($_REQUEST['hash']) && $_REQUEST['hash'] == md5($secret . $_REQUEST['name'])) {
			// This would be *very* dangerous outside a restricted area! We use logins, an MD5 hash and UNIX permissions to protect things a little...
			if (is_file($uploaddir . '/' . $_REQUEST['name'])) {
				unlink($uploaddir . '/' . $_REQUEST['name']);
			}
			$query = sprintf('DELETE FROM %s_photo WHERE id = %u', mysql_real_escape_string($_REQUEST['type']), mysql_real_escape_string($_REQUEST['id']));
			mysql_query($query);
		}
		// Not the best way to do it, but oh well...
		if (isset($_GET['r'])) {
			echo '<script type="text/javascript">window.location.replace(\'' . $_GET['r'] . '\');</script>';
		} else {
			echo '<script type="text/javascript">window.location.replace(\'/account\');</script>';
		}
		break;
	case 'account/admin/deletereport':
		// Delete a report
		if (!isset($_SESSION['loggedin'])) {
			echo '<p>You must be logged in to carry out this action.</p>';
		} else if ($_SESSION['level'] >= 3 && isset($_REQUEST['id']) && isset($_REQUEST['resource']) && ($_REQUEST['resource'] == 'photo')) {
			if ($_REQUEST['resource'] == 'photo') {
				$query = sprintf('DELETE FROM report_photo WHERE id = %u', mysql_real_escape_string($_REQUEST['id']));
			}
			mysql_query($query);
		}
		// Not the best way to do it, but oh well...
		echo '<script type="text/javascript">window.location.replace(\'/account\');</script>';
		break;
	case 'account/admin/updatelists':
		// Update politician lists
		if (!isset($_SESSION['loggedin'])) {
			echo '<p>You must be logged in to carry out this action.</p>';
		} else if ($_SESSION['level'] >= 3) {
			echo '<h2>Update politician lists</h2>';
			include_once '../auto/update.php';
			echo '<p><a href="/account">Back to account</a></p>';
		} else {
			// Not the best way to do it, but oh well...
			echo '<script type="text/javascript">window.location.replace(\'/account\');</script>';
		}
		break;
	default:
		// 404 Not Found error
		echo '<h2>404 Not Found</h2><p>Sorry, the page you were looking for could not be found.</p>';
		break;
}

?>

<div class="cleannclear"><p><a href="#top" accesskey="k" tabindex="3" title="Back to top of page [Accesskey: k]">Bac<strong class="accesskey">k</strong> to top</a></p></div>

</div>

<div id="footer"></div>

</div>

</body>
</html>

<?php

// Flush output buffer
ob_end_flush();

// Disconnect from MySQL
mysql_close();

?>
